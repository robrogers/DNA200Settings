Hi,

Really clear,

Use for selling = License
Personal = free

thanks.

Enjoy life is sweet ! 

For commercial license please email me - maellekeita@gmail.com